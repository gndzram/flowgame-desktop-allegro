#include <allegro5\allegro.h>
#include <allegro5\allegro_primitives.h>
#include <allegro5\allegro_image.h>
#include <allegro5\allegro_font.h>
#include <allegro5\allegro_ttf.h>
#include <conio.h>
#include <stdio.h>

#define tx 390
#define ty 120
#define clear al_clear_to_color(al_map_rgb(0, 0, 0));
#define draw al_flip_display();

typedef enum naslbitti
{
	ntcomplete,
	complete,
	perfect,
};

typedef struct oyundrm
{
	naslbitti nasl;
	int best;
	bool lock;
};

typedef struct coord
{
	int row;
	int column;
	int x;
	int y;
	float aralik;
};

typedef struct bol
{
	int bolum;
	int bs;
	int nflows;
};

typedef struct kare
{
	int rnk;
	int drm;
	int drm2;
	int drm3;
	int sira;
};

typedef struct clicked
{
	int row;
	int column;
	int rnk;
};

int x, y, v, l, islem = 1, r = 0, flows1 = 0, stop = 0, percent = 0, moves, res = 0, finish = 0;
coord gam;
bol bolum;
kare **oyn;
oyundrm *oyndrm;
clicked *pnts, nw, old, strt, tmp;
ALLEGRO_DISPLAY *display;
ALLEGRO_DISPLAY_MODE display_mode;
ALLEGRO_BITMAP *a, *b, *c, *d, *e, *f, *g, *h, *lb, *o, *rb, *s, *yb, *lock, *tick, *star;
ALLEGRO_FONT *font32, *font50, *font64, *font75, *font90, *font120;
ALLEGRO_MOUSE_STATE mouse_state;
ALLEGRO_EVENT event;
ALLEGRO_EVENT_QUEUE *event_queue;
ALLEGRO_COLOR color;

void menu(void);
void bitmaps(void);
void sound(char);
void drwimg(const char);
void settings(void);
int exit(void);
void about(void);
void help(void);
void play(void);
int sel(void);
char* itoc(int);
void doldur(coord);
void prcnt(void);
void flowctrl(void);
void rdoyn(void);
void drwpnt(void);
void game(void);
void drwdrm(void);
void drwgscr(void);
void chngdrm(void);
void chng(int);
void fnshscr(void);
ALLEGRO_COLOR getcolor(int);
void tksfrla(void);
void cut(void);
void cutslf(void);
coord tahta(int, int, int, int);
clicked getclck(int, int, coord);
void fonts(void);
void artint(void);

void main()
{
	int n, i, j;
	float es;
	FILE *f, *stt;
	oyndrm = (oyundrm*)calloc(sizeof(oyundrm), 150);
	stt=fopen("data/stt", "r");
	if (stt == NULL)
	{
		stt = fopen("data/stt", "w");
	}
	f=fopen("data/set", "r");
	if (f == NULL)
	{
		f = fopen("data/set", "w");
		fprintf(f, "%d,%d", 0, 0);
		rewind(f);
	}
	fscanf(f, "%d,%d", &v, &l);
	fread(oyndrm, sizeof(oyundrm), 150, stt);
	oyndrm[0].lock = 1;
	fcloseall();
	ShowWindow(FindWindowA("ConsoleWindowClass", NULL), 0);
	al_init();
	al_install_mouse();
	al_init_image_addon();
	al_init_primitives_addon();
	al_init_font_addon();
	al_init_ttf_addon();
	fonts();
	event_queue = al_create_event_queue();
	al_register_event_source(event_queue, al_get_mouse_event_source());
	al_set_new_display_flags(2);
	n = al_get_num_display_modes();
	al_get_display_mode(n - 1, &display_mode);
	y = display_mode.height;
	x = display_mode.width;
	display = al_create_display(x, y);
	if (display == NULL)
		return;
	bitmaps();
	Sleep(500);
	for (i = 255, j = -1; i < 256; i += j)
	{
		if (i == 0)
			j = 1;
		clear;
		al_draw_bitmap(g, 200, 75, 0);
		al_draw_filled_rectangle(0, 0, x, y, al_map_rgba(0, 0, 0, i));
		draw;
		Sleep(7);
	}
	Sleep(1000);
	menu();
}

void menu(void)
{
	int i;
	FILE *f;
	while (1)
	{
		clear;
		drwimg('f');
		al_draw_text(font90, al_map_rgb(0, 127, 127), 550, 290, 0, "play");
		al_draw_text(font90, al_map_rgb(0, 127, 127), 480, 370, 0, "settings");
		al_draw_text(font90, al_map_rgb(0, 127, 127), 520, 450, 0, "about");
		al_draw_text(font90, al_map_rgb(0, 127, 127), 550, 530, 0, "exit");
		draw;
		while (1)
		{
			al_get_mouse_state(&mouse_state);
			if (mouse_state.buttons & 1&&islem)
			{
				islem = 0;
				x = mouse_state.x;
				y = mouse_state.y;
				if ((x > 550 && x<726) && (y>300 && y<363))
				{
					sound('o');
					play();
					if (res)
					{
						res = 0;
					}
					break;
				}
				else if ((x>480 && x<811) && (y>380 && y<443))
				{
					sound('o');
					settings();
					break;
				}
				else if ((x>420 && x<760) && (y>460 && y<523))
				{
					sound('o');
					about();
					break;
				}
				else if ((x>550 && x<700) && (y>540 && y < 603))
				{
					sound('o');
					if (exit())
					{
						return;
					}
					break;
				}
				else if ((x<1060 && x>260) && (y<250 && y>20))
				{
					sound('o');
					for (i = 0; i < 150; i++)
					{
						oyndrm[i].lock = 1;
					}
					f = fopen("data/stt", "w");
					fwrite(oyndrm, sizeof(oyundrm), 150, f);
					fclose(f);
				}
			}
			al_get_next_event(event_queue, &event);
			if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
				islem = 1;
		}
	}
}

void drwimg(char p)
{
	switch (p)
	{
	case 'a':
		al_draw_bitmap(a, 260, 20, 0);
		break;
	case 'b':
		al_draw_bitmap(b, 10, 10, 0);
		break;
	case 'c':
		al_draw_bitmap(c, 390, 35, 0);
		break;
	case 'e':
		al_draw_bitmap(e, 360, 20, 0);
		break;
	case 'f':
		al_draw_bitmap(f, 260, 20, 0);
		break;
	case 'h':
		al_draw_bitmap(h, 260, 20, 0);
		break;
	case 'l':
		al_draw_bitmap(lb, 260, 70, 0);
		break;
	case 'o':
		al_draw_bitmap(o, 260, 70, 0);
		break;
	case 'r':
		al_draw_bitmap(rb, 880, 35, 0);
		break;
	case 's':
		al_draw_bitmap(s, 260, 20, 0);
		break;
	case 'y':
		al_draw_bitmap(yb, 635, 35, 0);
		break;
	}
}

void bitmaps(void)
{
	a = al_load_bitmap("data/a.png");
	b = al_load_bitmap("data/b.png");
	c = al_load_bitmap("data/c.png");
	d = al_load_bitmap("data/d.png");
	e = al_load_bitmap("data/e.png");
	f = al_load_bitmap("data/f.png");
	g = al_load_bitmap("data/g.png");
	h = al_load_bitmap("data/h.png");
	lb = al_load_bitmap("data/l.png");
	o = al_load_bitmap("data/o.png");
	rb = al_load_bitmap("data/r.png");
	s = al_load_bitmap("data/s.png");
	yb = al_load_bitmap("data/y.png");
	lock = al_load_bitmap("data/lock.png");
	tick = al_load_bitmap("data/tick.png");
	star = al_load_bitmap("data/star.png");
}

void sound(char s)
{
	if (v == 2)
		v = 0;
	s += v % 2;
	switch (s)
	{
	case 'b':
		PlaySound("data/ba", NULL, SND_FILENAME | SND_ASYNC);
		break;
	case 'f':
		PlaySound("data/fl", NULL, SND_FILENAME | SND_ASYNC);
		break;
	case 'o':
		PlaySound("data/fo", NULL, SND_FILENAME | SND_ASYNC);
		break;
	case 'l':
		PlaySound("data/le", NULL, SND_FILENAME | SND_ASYNC);
		break;
	}
}

int exit(void)
{
	int e = 0;
	clear;
	al_draw_text(font90, al_map_rgb(222, 85, 255), 380, 290, 0, "are you sure?");
	al_draw_text(font90, al_map_rgb(255, 0, 0), 360, 390, 0, "exit");
	al_draw_text(font90, al_map_rgb(0, 255, 0), 800, 390, 0, "no");
	drwimg('e');
	draw;
	while (1)
	{
		al_get_mouse_state(&mouse_state);
		if (mouse_state.buttons & 1 && islem)
		{
			x = mouse_state.x;
			y = mouse_state.y;
			if ((x > 360 && x<507) && (y>400 && y < 463))
			{
				e += 1;
				break;
			}
			else if ((x > 800 && x<905) && (y>400 && y < 463))
			{
				sound('b');
				break;
			}
		}
		al_get_next_event(event_queue, &event);
		if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
			islem = 1;
	}
	return e;
}

void settings(void)
{
	FILE *f;
	while (1)
	{
		clear;
		drwimg('b');
		drwimg('s');
		if (v == 0)
		{
			al_draw_text(font90, al_map_rgb(0, 255, 0), 450, 290, 0, "sound on");
		}
		else
		{
			al_draw_text(font90, al_map_rgb(255, 0, 0), 450, 290, 0, "sound off");
		}
		if (l == 1)
		{
			al_draw_text(font90, al_map_rgb(0, 255, 0), 450, 390, 0, "labels on");
		}
		else
		{
			al_draw_text(font90, al_map_rgb(255, 0, 0), 450, 390, 0, "labels off");
		}
		al_draw_text(font90, al_map_rgb(255, 0, 0), 450, 490, 0, "reset game");
		draw;
		if (l == 2)
		{
			l = 0;
		}
		while (1)
		{
			al_get_mouse_state(&mouse_state);
			if ((mouse_state.buttons & 1) && islem)
			{
				islem = 0;
				x = mouse_state.x;
				y = mouse_state.y;
				if ((x > 12 && x<72) && (y>12 && y<72))
				{
					sound('b');
					return;
				}
				else if ((x>450 && x<711) && (y>300 && y < 363))
				{
					v += 1;
					sound('o');
					break;
				}
				else if ((x>450 && x<700) && (y>400 && y < 463))
				{
					l += 1;
					sound('o');
					break;
				}
				else if ((x>450 && x<850) && (y>500 && y < 563))
				{
					sound('o');
					free(oyndrm);
					oyndrm = (oyundrm*)calloc(sizeof(oyundrm), 150);
					oyndrm[0].lock = 1;
					f = fopen("data/stt", "w");
					fwrite(oyndrm, sizeof(oyundrm), 150, f);
					fclose(f);
					res = 1;
					return;
				}
			}
			al_get_next_event(event_queue, &event);
			if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
				islem = 1;
		}
		f = fopen("data/set", "w");
		fprintf(f, "%d,%d", v, l);
		fclose(f);
	}
}

void about(void)
{
	FILE *f;
	int i;
	while (1)
	{
		clear;
		drwimg('b');
		drwimg('a');
		al_draw_text(font120, al_map_rgb(0, 255, 0), 350, 270, 0, "how to play");
		al_draw_ustr(font64, al_map_rgb(255, 0, 0), 400, 485, 0, al_ustr_new("Ramazan Gunduz"));
		draw;
		while (1)
		{
			al_get_mouse_state(&mouse_state);
			if ((mouse_state.buttons & 1) && islem)
			{
				islem = 0;
				x = mouse_state.x;
				y = mouse_state.y;
				if ((x > 12 && x<72) && (y>12 && y < 72))
				{
					sound('b');
					return;
				}
				else if ((x<970 && x>355) && (y<363 && y>300))
				{
					sound('o');
					help();
					break;
				}
			}
			al_get_next_event(event_queue, &event);
			if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
				islem = 1;
		}
	}
}

void help(void)
{
	clear;
	drwimg('b');
	drwimg('h');
	al_draw_text(font50, al_map_rgb(0, 255, 0), 300, 260, 0, "Drag to connect matching colors");
	al_draw_text(font50, al_map_rgb(0, 255, 0), 300, 305, 0, "with pipe, creating a flow.");
	al_draw_text(font50, al_map_rgb(0, 255, 0), 300, 360, 0, "Pair all colors, and cover the");
	al_draw_text(font50, al_map_rgb(0, 255, 0), 300, 405, 0, "entire board with pipe to solve");
	al_draw_text(font50, al_map_rgb(0, 255, 0), 300, 450, 0, "each puzzle.");
	al_draw_text(font50, al_map_rgb(0, 255, 0), 300, 505, 0, "But watch out, pipes will break if");
	al_draw_text(font50, al_map_rgb(0, 255, 0), 300, 550, 0, "they cross or overlap!");
	al_draw_text(font50, al_map_rgb(0, 255, 0), 300, 605, 0, "Too easy? Try selecting a larger");
	al_draw_text(font50, al_map_rgb(0, 255, 0), 300, 657, 0, "board.");
	draw;
	while (1)
	{
		al_get_mouse_state(&mouse_state);
		if ((mouse_state.buttons & 1) && islem)
		{
			islem = 0;
			x = mouse_state.x;
			y = mouse_state.y;
			if ((x > 12 && x<72) && (y>12 && y < 72))
			{
				sound('b');
				return;
			}
		}
		al_get_next_event(event_queue, &event);
		if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
			islem = 1;
	}
}

void play(void)
{
	while (1)
	{
		clear;
		drwimg('b');
		drwimg('o');
		al_draw_text(font90, al_map_rgb(255, 255, 255), 550, 260, 0, "5x5");
		al_draw_text(font90, al_map_rgb(255, 255, 255), 550, 340, 0, "6x6");
		al_draw_text(font90, al_map_rgb(255, 255, 255), 550, 420, 0, "7x7");
		al_draw_text(font90, al_map_rgb(255, 255, 255), 550, 500, 0, "8x8");
		al_draw_text(font90, al_map_rgb(255, 255, 255), 550, 580, 0, "9x9");
		draw;
		while (1)
		{
			al_get_mouse_state(&mouse_state);
			if ((mouse_state.buttons & 1) && islem)
			{
				islem = 0;
				x = mouse_state.x;
				y = mouse_state.y;
				if ((x > 12 && x<72) && (y>12 && y < 72))
				{
					sound('b');
					return;
				}
				else if ((x > 550 && x<700) && (y>270 && y < 333))
				{
					sound('o');
					bolum.bs = 5;
					break;
				}
				else if ((x > 550 && x<700) && (y>350 && y < 413))
				{
					sound('o');
					bolum.bs = 6;
					break;
				}
				else if ((x > 550 && x<700) && (y>430 && y < 493))
				{
					sound('o');
					bolum.bs = 7;
					break;
				}
				else if ((x > 550 && x<700) && (y>510 && y < 573))
				{
					sound('o');
					bolum.bs = 8;
					break;
				}
				else if ((x > 550 && x<700) && (y>590 && y < 653))
				{
					sound('o');
					bolum.bs = 9;
					break;
				}
			}
			al_get_next_event(event_queue, &event);
			if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
				islem = 1;
		}
		while (1)
		{
			bolum.bolum = sel();
			if (bolum.bolum == 0)
				break;
			if (bolum.bolum == -1)
				continue;
			if (bolum.bolum == -3 && bolum.bs > 5)
			{
				bolum.bs--;
				continue;
			}
			else if (bolum.bolum == -2 && bolum.bs < 9)
			{
				bolum.bs++;
				continue;
			}
			game();
			if (res)
				return;
		}
	}
}

int sel(void)
{
	coord a;
	int i, j, k = 0, kl, ciz=1;
	int xa, ya, xz, yz;
	while (1)
	{
		kl = (bolum.bs - 5) * 30;
		while (ciz)
		{
			clear;
			drwimg('b');
			drwimg('l');
			al_draw_textf(font64, al_map_rgb(255, 255, 255), 80, 10, 0, "Board size %d", bolum.bs);
			a = tahta(6, 5, 500, 300);
			if (bolum.bs > 5)
			{
				al_draw_bitmap(b, 400, 300, 0);
			}
			if (bolum.bs < 9)
			{
				al_draw_bitmap(rb, a.x + a.column*a.aralik + 35, 300, 0);
			}
			doldur(a);
			draw;
			ciz = 0;
			break;
		}
		al_get_mouse_state(&mouse_state);
		if ((mouse_state.buttons & 1) && islem)
		{
			islem = 0;
			x = mouse_state.x;
			y = mouse_state.y;
			if ((x > 12 && x<72) && (y>12 && y < 72))
			{
				sound('b');
				return 0;
			}
			else if ((x > 400 && x<466) && (y>300 && y < 366) && bolum.bs > 5)
			{
				sound('b');
				bolum.bs--;
				ciz = 1;
				continue;
			}
			else if ((x > a.x + a.column*a.aralik + 35 && x<a.x + a.column*a.aralik + 100) && (y>300 && y < 366) && bolum.bs < 9)
			{
				sound('o');
				bolum.bs++;
				ciz = 1;
				continue;
			}
			else if ((x > a.x&&x<a.x + a.column*a.aralik) && (y>a.y&&y < a.y + a.row*a.aralik))
			{
				for (j = 0; j < a.row; j++)
				for (i = 0; i < a.column; i++)
				{
					xa = a.x + i*a.aralik;
					ya = a.y + j*a.aralik;
					xz = xa + a.aralik + 1;
					yz = ya + a.aralik + 1;
					if ((x > xa&&x<xz) && (y>ya&&y < yz) && oyndrm[kl + k].lock)
					{
						sound('o');
						return k+1;
					}
					else if(!oyndrm[kl + k].lock)
						return -1;
					k++;
				}
			}
		}
		al_get_next_event(event_queue, &event);
		if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
			islem = 1;
	}
}

coord tahta(int a, int b, int xs, int ys)
{
	coord cor;
	float x, y, c, s, h = 680;
	s = h - ys;
	c = s / a;
	cor.aralik = c;
	cor.row = a;
	cor.column = b;
	cor.x = xs;
	cor.y = ys;
	for (y = ys; y <= h + 1; y += c)
	{
		al_draw_line(xs, y, xs + b*c, y,al_map_rgb(255,255,255),1);
	}
	for (x = xs; x <= (xs + b*c) + 1; x += c)
	{
		al_draw_line(x, ys, x, h, al_map_rgb(255, 255, 255), 1);
	}
	return cor;
}

void doldur(coord a)
{
	int i, j, k = (bolum.bs - 5) * 30;
	for (j = 0; j < a.row; j++)
	for (i = 0; i < a.column; i++)
	{
		if (!(oyndrm[k].lock))
		{
			al_draw_scaled_bitmap(lock, 0, 0, 300, 300, (a.x + a.aralik*i)+1, (a.y + a.aralik*j)+1, a.aralik-2, a.aralik-2, 0);
			continue;
		}
		else if (oyndrm[k].nasl == perfect)
		{
			al_draw_scaled_bitmap(star, 0, 0, 300, 300, (a.x + a.aralik*i), (a.y + a.aralik*j), a.aralik, a.aralik, 0);
		}
		else if (oyndrm[k].nasl == complete)
		{
			al_draw_scaled_bitmap(tick, 0, 0, 300, 300, (a.x + a.aralik*i), (a.y + a.aralik*j), a.aralik, a.aralik, 0);
		}
		k++;
	}
	al_draw_filled_rectangle(a.x-1, a.y-1, a.x + a.aralik*a.column, a.y + a.aralik*a.row, al_map_rgba(0, 0, 0, 150));
	k = 0;
	for (j = 0; j < a.row; j++)
	for (i = 0; i < a.column; i++)
	{
		k++;
		if (k < 10)
		{
			al_draw_textf(font50, al_map_rgb(255, 255, 255), (a.x + a.aralik*i) + 18, (a.y + a.aralik*j) + 10, 0, "%d", k);
		}
		else
			al_draw_textf(font50, al_map_rgb(255, 255, 255), (a.x + a.aralik*i) + 5, (a.y + a.aralik*j) + 10, 0, "%d", k);
	}
}

clicked getclck(int x, int y, coord a)
{
	clicked b;
	float i, j;
	float xa, ya, xz, yz;
	for (j = 0; j < a.row; j++)
	for (i = 0; i < a.column; i++)
	{
		xa = a.x + i*a.aralik;
		ya = a.y + j*a.aralik;
		xz = xa + a.aralik + 1;
		yz = ya + a.aralik + 1;
		if ((x > xa&&x<xz) && (y>ya&&y < yz))
		{
			b.row = j;
			b.column = i;
			b.rnk = oyn[(int)j][(int)i].rnk;
			return b;
		}
	}
	b.row = -1;
	b.column = -1;
	b.rnk = 0;
	return b;
}

void rdoyn(void)
{
	int i, b = 0, temp[3];
	char c[20];
	FILE *d;
	free(pnts);
	pnts = (clicked*)malloc(sizeof(clicked));
	strcpy(c, "data/");
	strcat(c, itoc(bolum.bs));
	d = fopen(c, "r");
	while (1)
	{
		fscanf(d, "%s", c);
		if (atoi(c) == bolum.bolum)
		{
			while (1)
			{
				fscanf(d, "%s ", c);
				if (strlen(c) == 3)
					break;
				pnts = (clicked*)realloc(pnts, sizeof(clicked)*(b + 1));
				sscanf(c, "%d,%d,%d ", &temp[0], &temp[1], &temp[2]);
				pnts[b].row = temp[0];
				pnts[b].column = temp[1];
				pnts[b].rnk = temp[2];
				oyn[temp[0]][temp[1]].drm = 0;
				oyn[temp[0]][temp[1]].drm2 = 5;
				oyn[temp[0]][temp[1]].rnk = temp[2];
				b++;
			}
			bolum.nflows = b / 2;
			break;
		}
		else
		{
			while (strlen(c) != 3)
			{
				fscanf(d, "%s ", c);
			}
		}
	}
	fclose(d);
}

char* itoc(int a)
{
	char *c, t;
	int i = 0, j;
	c = (char*)malloc(i + 1);
	while (a > 0)
	{
		c[i] = (a % 10) + 48;
		a /= 10;
		i++;
		c = (char*)realloc(c, i + 1);
	}
	for (j = 0; j < i / 2; j++)
	{
		t = c[j];
		c[j] = c[i - j - 1];
		c[i - j - 1] = t;
	}
	c[i] = '\0';
	return c;
}

void flowctrl(void)
{
	int i, j;
	int flows = 0;
	for (i = 0; i < bolum.bs; i++)
	for (j = 0; j < bolum.bs; j++)
	{
		if (oyn[i][j].drm2 == 5 && oyn[i][j].drm != 0)
		{
			flows++;
		}
	}
	if (flows > flows1)
	{
		if (flows != bolum.nflows)
			sound('o');
		flows1 = flows;
	}
	else if (flows < flows1)
	{
		sound('l');
		flows1--;
	}
	if (flows1 == bolum.nflows)
	{
		sound('f');
	}
}

void prcnt(void)
{
	int i, j;
	float percent1 = 0;
	percent = 0;
	for (i = 0; i < bolum.bs; i++)
	for (j = 0; j < bolum.bs; j++)
	{
		if (oyn[i][j].drm != 0)
		{
			percent1++;
		}
	}
	percent = 100 * percent1 / (bolum.bs*bolum.bs - bolum.nflows);
}

void cutslf(void)
{
	int i, j, rnk, sir;
	rnk = oyn[nw.row][nw.column].rnk;
	sir = oyn[nw.row][nw.column].sira;
	for (i = 0; i < bolum.bs; i++)
	for (j = 0; j < bolum.bs; j++)
	{
		if (oyn[i][j].rnk == 0)
			continue;
		if ((oyn[i][j].rnk == rnk) && (oyn[i][j].sira>sir))
		{
			oyn[i][j].sira = 0;
			oyn[i][j].drm = 0;
			if (oyn[i][j].drm2 == 0)
			{
				oyn[i][j].rnk = 0;
			}
			if (oyn[i][j].drm3)
			{
				oyn[i][j].drm3 = 0;
			}
		}
	}
	clear
	drwgscr();
	draw
}

void tksfrla(void)
{
	int i, j, r;
	for (i = 0; i < bolum.bs; i++)
	for (j = 0; j < bolum.bs; j++)
	{
		if (oyn[i][j].drm3 && (oyn[i][j].rnk == oyn[strt.row][strt.column].rnk))
		{
			oyn[i][j].drm3 = 0;
		}
	}
	if (oyn[strt.row][strt.column].drm2 > 0)
	{
		r = oyn[strt.row][strt.column].rnk;
		for (i = 0; i < bolum.bs; i++)
		for (j = 0; j < bolum.bs; j++)
		{
			if (r == oyn[i][j].rnk)
			{
				if (oyn[i][j].drm2 > 0)
				{
					oyn[i][j].drm = 0;
					oyn[i][j].drm2 = 5;
					oyn[i][j].sira = 0;
					continue;
				}
				oyn[i][j].drm = 0;
				oyn[i][j].rnk = 0;
				oyn[i][j].sira = 0;
			}
		}
		oyn[strt.row][strt.column].drm2 = 6;
	}
	else
	{
		r = oyn[strt.row][strt.column].sira;
		for (i = 0; i < bolum.bs; i++)
		for (j = 0; j < bolum.bs; j++)
		{
			if (oyn[i][j].sira > r && oyn[i][j].rnk == oyn[strt.row][strt.column].rnk)
			{
				if (oyn[i][j].drm2 > 0)
				{
					oyn[i][j].drm = 0;
					oyn[i][j].drm2 = 5;
					oyn[i][j].sira = 0;
					continue;
				}
				oyn[i][j].drm = 0;
				oyn[i][j].rnk = 0;
				oyn[i][j].sira = 0;
			}
		}
	}
	clear;
	prcnt();
	flowctrl();
	drwgscr();
	draw;
}

void cut(void)
{
	int i, j, rnk, sir;
	rnk = oyn[nw.row][nw.column].rnk;
	sir = oyn[nw.row][nw.column].sira;
	for (i = 0; i < bolum.bs; i++)
	for (j = 0; j < bolum.bs; j++)
	{
		if ((oyn[i][j].sira >= sir) && (oyn[i][j].rnk == rnk))
		{
			if (oyn[i][j].drm2 > 0)
			{
				oyn[i][j].drm = 0;
				oyn[i][j].drm3 = 0;
				oyn[i][j].sira = 0;
				continue;
			}
			oyn[i][j].sira = 0;
			oyn[i][j].drm = 0;
			oyn[i][j].drm3 = 0;
			oyn[i][j].rnk = 0;
		}
	}
	clear;
	flowctrl();
	drwgscr();
	draw;
}

void game(void)
{
	int i, j, xs, ys, xc, yc, k;
	while (1)
	{
		free(oyn);
		oyn = (kare**)calloc(bolum.bs, sizeof(kare));
		for (i = 0; i < bolum.bs; i++)
		{
			oyn[i] = (kare*)calloc(bolum.bs, sizeof(kare));
		}
		r = 0;
		percent = 0;
		flows1 = 0;
		moves = 0;
		gam = tahta(bolum.bs, bolum.bs, tx, ty);
		xs = gam.x;
		ys = gam.y;
		xc = gam.x + gam.aralik*gam.column;
		yc = gam.y + gam.aralik*gam.row;
		rdoyn();
		clear;
		drwgscr();
		draw;
		while (1)
		{
			if ((flows1 == bolum.nflows) && (percent == 100))
			{
				fnshscr();
				drwgscr;
				fnshscr();
				while (1)
				{
					al_get_mouse_state(&mouse_state);
					if ((mouse_state.buttons & 1) && islem)
					{
						islem = 0;
						x = mouse_state.x;
						y = mouse_state.y;
						if ((x > 12 && x<72) && (y>12 && y < 72))
						{
							sound('b');
							res = 0;
							return;
						}
						else if ((x>1199 && x < 1264) && (y<75 && y>10))
						{
							sound('o');
							settings();
							if (res)
								return;
							fnshscr();
						}
						else if ((x<930 && x>470) && (y<393 && y>299))
						{
							sound('o');
							if (bolum.bolum < 30)
								bolum.bolum++;
							else if (bolum.bs == 9)
								return;
							else
							{
								bolum.bolum = 1;
								bolum.bs++;
							}
							break;
						}
						else if ((x<930 && x>470) && (y<493 && y>399))
						{
							sound('o');
							break;
						}
					}
					al_get_next_event(event_queue, &event);
					if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
						islem = 1;
				}
				break;
			}
			al_get_mouse_state(&mouse_state);
			if ((mouse_state.buttons & 1) && islem)
			{
				islem = 0;
				x = mouse_state.x;
				y = mouse_state.y;
				k = (bolum.bs - 5) * 30 + bolum.bolum;
				if ((x > 12 && x<72) && (y>12 && y < 72))
				{
					sound('b');
					res = 0;
					return;
				}
				else if ((x>1199 && x<1264) && (y<75 && y>10))
				{
					sound('o');
					settings();
					if (res)
						return;
					clear;
					drwgscr();
					draw;
				}
				else if ((x>gam.x&&x<(gam.x + gam.column*gam.aralik)) && (y>gam.y&&y < (gam.y + gam.row*gam.aralik)))
				{
					strt = getclck(x, y, gam);
					if (strt.rnk != 0)
					{
						tksfrla();
						chngdrm();
					}
				}
				else if ((x>880 && x < 945) && (y<100 && y>35) && (bolum.bs != 9 || bolum.bolum != 30) && oyndrm[k].lock)
				{
					if (bolum.bolum == 30)
					{
						bolum.bolum = 0;
						bolum.bs++;
					}
					sound('o');
					bolum.bolum += 1;
					break;
				}
				else if ((x > 390 && x<455) && (y<100 && y>35) && (bolum.bs>5 || bolum.bolum != 1))
				{
					if (bolum.bolum == 1)
					{
						bolum.bolum = 31;
						bolum.bs -= 1;
					}
					sound('b');
					bolum.bolum--;
					break;
				}
				else if ((x > 635 && x < 700) && (y<100 && y>35))
				{
					sound('l');
					break;
				}
			}

			al_get_next_event(event_queue, &event);
			if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
				islem = 1;
		}
	}
}

void drwpnt(void)
{
	char lab[2];
	lab[1] = 0;
	int i, j, rnk, drm;
	int cntrx, cntry, r;
	r = (gam.aralik * 3) / 8;
	for (i = 0; i < 2 * bolum.nflows; i++)
	{
		*lab = 64;
		rnk = pnts[i].rnk;
		color = getcolor(rnk);
		cntrx = gam.x + pnts[i].column*gam.aralik + gam.aralik / 2;
		cntry = gam.y + pnts[i].row*gam.aralik + gam.aralik / 2;
		al_draw_filled_circle(cntrx, cntry, r, color);
		(*lab) += rnk;
		if (l == 1)
		{
			al_draw_text(font32, getcolor(13), cntrx - gam.aralik / 20 - bolum.bs, cntry - gam.aralik / 20 - bolum.bs, 0, lab);
		}
	}
}

void drwdrm(void)
{
	float drm, rnk, cntrx, cntry, r, x1, y1, x2, y2;
	int i, j;
	r = gam.aralik / 5;
	for (i = 0; i < bolum.bs; i++)
	for (j = 0; j < bolum.bs; j++)
	{
		if (oyn[i][j].rnk == 0)
			continue;
		drm = oyn[i][j].drm;
		rnk = oyn[i][j].rnk;
		color = getcolor(rnk);
		if (oyn[i][j].drm3)
		{
			al_draw_filled_rectangle(gam.x + j*gam.aralik + 1, gam.y + i*gam.aralik + 1, gam.x + (j + 1)*gam.aralik - 1, gam.y + (i + 1)*gam.aralik - 1, color);
			al_draw_filled_rectangle(gam.x + j*gam.aralik + 1, gam.y + i*gam.aralik + 1, gam.x + (j + 1)*gam.aralik - 1, gam.y + (i + 1)*gam.aralik - 1, al_map_rgba(0,0,0,200));
		}
	}
	for (i = 0; i < bolum.bs; i++)
	for (j = 0; j < bolum.bs; j++)
	{
		if ((oyn[i][j].drm == 0))
			continue;
		drm = oyn[i][j].drm;
		rnk = oyn[i][j].rnk;
		cntrx = gam.x + j*gam.aralik + gam.aralik / 2;
		cntry = gam.y + i*gam.aralik + gam.aralik / 2;
		color = getcolor(rnk);
		if (drm == 1)
		{
			al_draw_filled_rectangle(cntrx - r, cntry - gam.aralik, cntrx + r, cntry, color);
		}
		else if (drm == 2)
		{
			al_draw_filled_rectangle(cntrx, cntry - r, cntrx + gam.aralik, cntry + r, color);
		}
		else if (drm == 3)
		{
			al_draw_filled_rectangle(cntrx - r, cntry, cntrx + r, cntry + gam.aralik, color);
		}
		else if (drm == 4)
		{
			al_draw_filled_rectangle(cntrx - gam.aralik, cntry - r, cntrx, cntry + r, color);
		}
		al_draw_filled_circle(cntrx, cntry, r, color);
	}
}

void drwgscr(void)
{
	int k = (bolum.bs - 5) * 30 + bolum.bolum - 1;
	tahta(bolum.bs, bolum.bs, tx, ty);
	drwdrm();
	drwpnt();
	color = getcolor(13);
	al_draw_text(font75, color, 50, 400, 0, "pipe");
	al_draw_textf(font75, color, 50, 480, 0, "%d %%", percent);
	al_draw_text(font75, color, 50, 200, 0, "flows:");
	al_draw_textf(font75, color, 50, 280, 0, "%d / %d", flows1, bolum.nflows);
	al_draw_text(font75, color, 1000, 400, 0, "best:");
	if (oyndrm[k].best==0)
		al_draw_text(font75, color, 1000, 480, 0, "-");
	else
		al_draw_textf(font75, color, 1000, 480, 0, "%d", oyndrm[k].best);
	drwimg('b');
	al_draw_bitmap(d, 1199, 10, 0);
	if (oyndrm[k].nasl == perfect)
		al_draw_scaled_bitmap(star, 0, 0, 300, 300, 1000, 600, 80, 80, 0);
	else if (oyndrm[k].nasl == complete)
		al_draw_scaled_bitmap(tick, 0, 0, 300, 300, 1000, 600, 80, 80, 0);
	if (bolum.bolum != 1 || bolum.bs != 5)
		drwimg('c');
	drwimg('y');
	if ((bolum.bolum != 30 || bolum.bs != 9) && oyndrm[k + 1].lock)
		drwimg('r');
	al_draw_textf(font75, color, 80, 10, 0, "level %d",bolum.bolum);
	al_draw_text(font75, color, 1000, 200, 0, "moves");
	al_draw_textf(font75, color, 1000, 280, 0, "%d", moves);
}

void chngdrm(void)
{
	int i, j;
	old = strt;
	nw = strt;
	al_get_next_event(event_queue, &event);
	if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
		islem = 1;
	while (!islem)
	{
		al_get_mouse_state(&mouse_state);
		x = mouse_state.x;
		y = mouse_state.y;
		clear
		drwgscr();
		al_draw_filled_circle(x, y, 30, al_map_rgba(100, 100, 100,200));
		draw
		if ((x > gam.x&&x<(gam.x + gam.column*gam.aralik)) && (y>gam.y&&y < (gam.y + gam.row*gam.aralik)))
		{
			al_get_next_event(event_queue, &event);
			if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
			{
				islem = 1;
			}
			nw = getclck(x, y, gam);
			if (nw.row == old.row&&nw.column == old.column)
			{
				continue;
			}
			else if (nw.row == old.row&&nw.column == old.column + 1)
			{
				chng(4);
			}
			else if (nw.row == old.row&&nw.column == old.column - 1)
			{
				chng(2);
			}
			else if (nw.row == old.row + 1 && nw.column == old.column)
			{
				chng(1);
			}
			else if (nw.row == old.row - 1 && nw.column == old.column)
			{
				chng(3);
			}
			else artint();
			clear;
			prcnt();
			if (islem)
				flowctrl();
			drwgscr();
			al_draw_filled_circle(x, y, 30, al_map_rgba(100, 100, 100, 200));
			draw;
			if (stop)
			{
				stop = 0;
				break;
			}
		}
		al_get_next_event(event_queue, &event);
		if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
		{
			islem = 1;
			finish = 0;
		}
	}
	if (islem)
		flowctrl();
	for (i = 0; i < bolum.bs; i++)
	for (j = 0; j < bolum.bs; j++)
	{
		if (oyn[i][j].rnk && ((oyn[i][j].drm2 > 5) || oyn[i][j].drm))
			oyn[i][j].drm3 = 1;
	}
	if (r == 0)
		moves++;
	else if ((r != 0) && r != strt.rnk)
		moves++;
	r = strt.rnk;
	clear;
	drwgscr();
	if (!islem)
		al_draw_filled_circle(x, y, 30, al_map_rgba(100, 100, 100, 200));
	draw;
}

void chng(int a)
{
	int i, j;
	if (oyn[nw.row][nw.column].rnk==0)
	{
		if (oyn[old.row][old.column].drm2 > 0 && !finish)
		{
			oyn[old.row][old.column].drm2 = 6;
			finish = 1;
		}
		oyn[nw.row][nw.column].rnk = oyn[old.row][old.column].rnk;
		oyn[nw.row][nw.column].drm = a;
		oyn[nw.row][nw.column].sira = oyn[old.row][old.column].sira + 1;
		old = nw;
	}
	else
	{
		if (oyn[old.row][old.column].drm2 > 0 && !finish)
		{
			oyn[old.row][old.column].drm2 = 6;
			finish = 1;
		}
		if (oyn[nw.row][nw.column].drm2 == 0)
		{
			if (oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
			{
				cutslf();
				old = nw;
			}
			else
			{
				cut();
				oyn[nw.row][nw.column].rnk = oyn[old.row][old.column].rnk;
				oyn[nw.row][nw.column].drm = a;
				oyn[nw.row][nw.column].sira = oyn[old.row][old.column].sira + 1;
				old = nw;
				return;
			}
		}
		else
		{
			if (oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk&&oyn[nw.row][nw.column].drm2 == 5)
			{
				oyn[nw.row][nw.column].drm = a;
				oyn[nw.row][nw.column].sira = oyn[old.row][old.column].sira + 1;
				prcnt();
				al_get_mouse_state(&mouse_state);
				tmp = getclck(mouse_state.x, mouse_state.y, gam);
				while (!((tmp.row == old.row) && (tmp.column == old.column)) && !islem)
				{
					al_get_mouse_state(&mouse_state);
					al_get_next_event(event_queue, &event);
					if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
						islem = 1;
					tmp = getclck(mouse_state.x, mouse_state.y, gam);
					clear;
					drwgscr();
					if (!islem)
						al_draw_filled_circle(mouse_state.x, mouse_state.y, 30, al_map_rgba(100, 100, 100, 200));
					draw;
				}
				if ((tmp.row == old.row) && (tmp.column == old.column))
				{
					oyn[nw.row][nw.column].drm = 0;
					oyn[nw.row][nw.column].sira = 0;
					nw = old;
				}
				else
				{
					stop++;
				}

			}
			else if (oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk&&oyn[nw.row][nw.column].drm2 == 6)
			{
				cutslf();
				old = nw;
			}
			else
			{
				return;
			}
		}
	}
}

void fnshscr(void)
{
	int k = (bolum.bs - 5) * 30 + bolum.bolum - 1;
	FILE *stt;
	oyndrm[k+1].lock = 1;
	if (oyndrm[k].best)
	{
		if (moves < oyndrm[k].best)
			oyndrm[k].best = moves;
	}
	else
		oyndrm[k].best = moves;
	clear;
	drwgscr();
	int i;
	color = getcolor(13);
	al_draw_rectangle(295, 95, 1095, 605, color, 10);
	al_draw_filled_rectangle(300, 100, 1090, 600, al_map_rgba(0, 0, 0, 220));
	al_draw_rectangle(470, 299, 930, 393, color, 1);
	al_draw_rectangle(470, 399, 930, 493, color, 1);
	al_draw_text(font50, color, 450, 200, 0, "You completed the level");
	al_draw_textf(font50, color, 580, 250, 0, "in %d moves.", moves);
	if (moves == flows1)
	{
		al_draw_text(font75, color, 560, 130, 0, "Perfect!");
		oyndrm[k].nasl = perfect;
	}
	else
	{
		al_draw_text(font75, color, 460, 130, 0, "Level complete!");
		if (oyndrm[k].nasl == ntcomplete)
			oyndrm[k].nasl = complete;
	}
	if (bolum.bolum < 30)
	{
		al_draw_text(font90, color, 520, 300, 0, "next level");
	}
	else if (bolum.bs == 9)
	{
		al_draw_text(font90, color, 560, 300, 0, "go back");
	}
	else
	{
		al_draw_textf(font90, color, 540, 300, 0, "play %dx%d", bolum.bs + 1, bolum.bs + 1);
	}
	al_draw_text(font90, color, 515, 400, 0, "play again");
	draw;
	fopen_s(&stt, "data/stt", "w");
	fwrite(oyndrm, sizeof(oyundrm), 150, stt);
	fclose(stt);
}

ALLEGRO_COLOR getcolor(int i)
{

	switch (i)
	{
	case 0:
		return al_map_rgb(0, 0, 0);
	case 1:
		return al_map_rgb(255, 0, 0);
	case 2:
		return al_map_rgb(0, 255, 0);
	case 3:
		return al_map_rgb(0, 0, 255);
	case 4:
		return al_map_rgb(190, 190, 0);
	case 5:
		return al_map_rgb(255, 0, 255);
	case 6:
		return al_map_rgb(0, 255, 255);
	case 7:
		return al_map_rgb(127, 127, 127);
	case 8:
		return al_map_rgb(255, 157, 0);
	case 9:
		return al_map_rgb(163, 73, 163);
	case 10:
		return al_map_rgb(255, 204, 115);
	case 11:
		return al_map_rgb(127, 0, 0);
	case 12:
		return al_map_rgb(255, 127, 192);
	case 13:
		return al_map_rgb(255, 255, 255);
	}

}

void fonts(void)
{
	font32 = al_load_ttf_font("data/calibri.ttf", 32, 1);
	font50 = al_load_ttf_font("data/calibri.ttf", 50, 1);
	font64 = al_load_ttf_font("data/calibri.ttf", 64, 1);
	font75 = al_load_ttf_font("data/calibri.ttf", 75, 1);
	font90 = al_load_ttf_font("data/calibri.ttf", 90, 1);
	font120 = al_load_ttf_font("data/calibri.ttf", 120, 1);
}

void artint(void)
{
	clicked tempnw;
	tempnw = nw;
	if (nw.column == old.column)
	{
		if (oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
		{
			if (oyn[nw.row][nw.column].drm2 != 5)
			{
				cutslf();
				old = nw;
				return;
			}
		}
		if (old.row < nw.row)
		{
			nw = old;
			nw.row += 1;
			while (nw.row < tempnw.row)
			{
				if (oyn[nw.row][nw.column].drm2 > 0)
				{
					if (oyn[nw.row][nw.column].drm2 == 6 && oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
					{
						cutslf();
						old = nw;
					}
					else if (oyn[nw.row][nw.column].drm2 == 5 && oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
					{
						chng(1);
						return;
					}
					else return;
				}
				if (oyn[nw.row][nw.column].rnk == 0)
				{
					chng(1);
				}
				else if (oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
				{
					cutslf();
					old = nw;
				}
				else
				{
					cut();
					chng(1);
				}
				nw.row += 1;
			}
			return;
		}
		else if (old.row > nw.row)
		{
			nw = old;
			nw.row -= 1;
			while (nw.row > tempnw.row)
			{
				if (oyn[nw.row][nw.column].drm2 > 0)
				{
					if (oyn[nw.row][nw.column].drm2 == 6 && oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
					{
						cutslf();
						old = nw;
					}
					else if (oyn[nw.row][nw.column].drm2 == 5 && oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
					{
						chng(3);
						return;
					}
					else return;
				}
				if (oyn[nw.row][nw.column].rnk == 0)
				{
					chng(3);
				}
				else if (oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
				{
					cutslf();
					old = nw;
				}
				else
				{
					cut();
					chng(3);
				}
				nw.row -= 1;
			}
			return;
		}
	}
	else if (nw.row == old.row)
	{
		if (oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
		{
			if (oyn[nw.row][nw.column].drm2 != 5)
			{
				cutslf();
				old = nw;
				return;
			}
		}
		if (old.column < nw.column)
		{
			nw = old;
			nw.column += 1;
			while (nw.column < tempnw.column)
			{
				if (oyn[nw.row][nw.column].drm2 > 0)
				{
					if (oyn[nw.row][nw.column].drm2 == 6 && oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
					{
						cutslf();
						old = nw;
					}
					else if (oyn[nw.row][nw.column].drm2 == 5 && oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
					{
						chng(4);
						return;
					}
					else return;
				}
				if (oyn[nw.row][nw.column].rnk == 0)
				{
					chng(4);
				}
				else if (oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
				{
					cutslf();
					old = nw;
				}
				else
				{
					cut();
					chng(4);
				}
				nw.column += 1;
			}
			return;
		}
		else if (old.column > nw.column)
		{
			nw = old;
			nw.column -= 1;
			while (nw.column > tempnw.column)
			{
				if (oyn[nw.row][nw.column].drm2 > 0)
				{
					if (oyn[nw.row][nw.column].drm2 == 6 && oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
					{
						cutslf();
						old = nw;
					}
					else if (oyn[nw.row][nw.column].drm2 == 5 && oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
					{
						chng(2);
						return;
					}
					else return;
				}
				if (oyn[nw.row][nw.column].rnk == 0)
				{
					chng(2);
				}
				else if (oyn[nw.row][nw.column].rnk == oyn[old.row][old.column].rnk)
				{
					cutslf();
					old = nw;
				}
				else
				{
					cut();
					chng(2);
				}
				nw.column -= 1;
			}
			return;
		}
	}
}
